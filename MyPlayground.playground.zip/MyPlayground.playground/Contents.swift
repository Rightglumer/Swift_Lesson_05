import Cocoa

enum WindowState {
    case Open, Close
}

enum EngineState {
    case Started, Stopped
}

protocol Car {
    var model : String { get }
    var year : Int { get }
    var windowState : WindowState { get set }
    var engineState : EngineState { get set }
    func goDrive()
    func printState()
}

extension Car {
    mutating func openWindow() {
        windowState = .Open
    }
    mutating func closeWindow() {
        windowState = .Close
    }
    
    mutating func startEngine() {
        self.engineState = .Started
    }
    mutating func stopEngine() {
        self.engineState = .Stopped
    }
}

class sportCar : Car {
    func printState() {
        print("Windows are \(windowState)")
        print("Engine is \(engineState)")
    }
    
    func goDrive() {
        engineState = .Started
        print("wrooom wrooom")
    }
    
    var model: String
    var year: Int
    var maxPassenger : Int
    var windowState: WindowState
    var engineState: EngineState
    
    init (model : String, year : Int, maxPassenger : Int) {
        self.model = model
        self.year = year
        self.maxPassenger = maxPassenger
        windowState = .Close
        engineState = .Stopped
    }
}

extension sportCar : CustomStringConvertible {
    var description: String {
        return "Sport car"
    }
}

class trunkCar : Car {
    func printState() {
        print("Windows are \(windowState)")
        print("Engine are \(engineState)")
    }
    
    func goDrive() {
        engineState = .Started
        print("blurb blurb")
    }
    
    var model: String
    var year: Int
    var maxCapacity : Double
    var windowState: WindowState
    var engineState: EngineState
    
    init (model : String, year : Int, maxCapacity : Double) {
        self.model = model
        self.year = year
        self.maxCapacity = maxCapacity
        windowState = .Close
        engineState = .Stopped
    }
}

extension trunkCar : CustomStringConvertible {
    var description: String {
        return "Trunk car"
    }
}

var ferrari : sportCar = sportCar(model: "f45", year: 2020, maxPassenger: 3)
ferrari.printState()
ferrari.goDrive()
ferrari.openWindow()
ferrari.printState()
print(ferrari)

var cement : trunkCar = trunkCar(model: "gazelle", year: 2018, maxCapacity: 17.6)
print(cement)
cement.goDrive()
cement.printState()
